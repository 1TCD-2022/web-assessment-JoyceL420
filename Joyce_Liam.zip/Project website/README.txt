Oh hey you actually clicked on the readme document uhhhhhhhhh... I wasnt expecting this


The latest version is the FINAL VERSION of the website. It just includes some changes with me using style with images because THAT ISNT ALLOWED.

You can navigate through earlier versions by just looking in the versions folder. In that folder you will find other folders conveniently named what versions they are! :D

Have fun looking at this crime against humanity!


The website works on:
Microsoft edge
Google
Firefox (nightly)

Not internet explorer unfortunately (it does work but barely)


 _______
|_______|
|
|_______
|_______|
|
|_______
|_______|